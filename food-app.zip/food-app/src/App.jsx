import { useState } from 'react'
import Search from './components/Search'
import Foodlist from './components/Foodlist'
import Nav from './components/Nav'
import "./App.css"
import Container from './components/Container'
import Innercomponent from './components/Innercomponent'
import Fooddetails from './components/Fooddetails'


function App() {
   const [fooddata, setFooddata] = useState([])
   const [foodId,setFoodId] = useState("658615")
   return (
      <div>
         <Nav />
         <Search fooddata={fooddata} setFooddata={setFooddata} />
         <Container>
            <Innercomponent>
               <Foodlist setFoodId = {setFoodId} fooddata={fooddata} />
            </Innercomponent>
            <Innercomponent>
               <Fooddetails foodId = {foodId} />
            </Innercomponent>
         </Container>

      </div>
   )
}

export default App
