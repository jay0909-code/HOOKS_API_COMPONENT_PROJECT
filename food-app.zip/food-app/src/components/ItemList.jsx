import Item from "./Item";

export default function ItemList({food,isLoading}){
    return(
        // {food.extendedIngredients ? (
        //     food.extendedIngredients.map((item) => (
        //         <div key={item.id}>
        //             <img
        //                 src={`https://spoonacular.com/cdn/ingredients_100x100/${item.image}`}
        //                 alt={item.name}
        //             />
        //             <h3>{item.name}</h3>
        //         </div>
        //     ))
        // ) : (
        //     <p>Loading ingredients...</p>
        // )}
        <div>
            {
            isLoading ? (<p>isLoading...</p>):(
               food.extendedIngredients.map((item)=>(
                <Item item={item}/>
               )) 
            )
        }
        </div>
    )
}