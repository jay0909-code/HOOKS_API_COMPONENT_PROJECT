import styles from "./innercomponent.module.css"
export default function Innercomponent({children}){
    return <div className={styles.innerContainer}>{children}</div>
}