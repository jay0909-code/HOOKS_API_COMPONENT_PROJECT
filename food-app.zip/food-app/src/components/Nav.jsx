import styels from "./nav.module.css"
export default function Nav(){
    return <div className={styels.nav}>Food App</div>
}