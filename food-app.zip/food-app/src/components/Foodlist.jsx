import Fooditem from "./Fooditem";

export default function Foodlist({fooddata,setFoodId}) {
    return (
        <div>
            {fooddata.map((food) => (
                <Fooditem key={food.id} food={food} setFoodId={setFoodId}  />
            ))}
        </div>
    )
}