import { useEffect, useState } from "react"
import styles from "./fooddetails.module.css"
import ItemList from "./ItemList"
export default function Fooddetails({ foodId }) {
    const [food, setFood] = useState({})
    const [isLoading, setIsLoading] = useState(true)
    const URL = `https://api.spoonacular.com/recipes/${foodId}/information`
    const API_KEY = "d30707709beb4b81a5c8e49cb3fb6547"
    useEffect(() => {
        async function fetchFood() {
            const res = await fetch(`${URL}?apiKey=${API_KEY}`);
            const data = await res.json()
            console.log(data);
            setFood(data)
            setIsLoading(false)
        }
        fetchFood()
    }, [foodId])
    return (
        <div>
            <div className={styles.recipeCard}>
                <h1 className={styles.recipeName}>{food.title}</h1>
                <img className={styles.recipeImage} src={food.image} alt="" />
            </div>
            <div className={styles.recipeDetails}>
                <span>
                    <strong>Time:{food.readyInMinutes} Minutes</strong>
                </span>
                <span>
                    <strong> Serves {food.servings}</strong>
                </span>
                <span>
                    {food.vegetarian ? "Vegetarian" : "Non-Vegetarian"}
                </span>
                <span>
                    {food.vegan ? "Vegan" : "Non-Vegan"}
                </span>
            </div>
            <div>
                $<span>{food.pricePerServing / 100} Per Serving</span>
            </div>

            {/* <h2>Ingredients</h2>
            {food.extendedIngredients ? (
                food.extendedIngredients.map((item) =>(
                <div key={item.id}>
                    <img src={`https://spoonacular.com/cdn/ingredients_100x100/${item.image}`} alt={item.name} />

                    <h3>{item.name}</h3>
                </div>
            ))
        
        ):(
            <p>Loading Ingredients.....</p>
        )} */}

            <h2>Ingredients</h2>
            

            <ItemList food={food} isLoading={isLoading} />




            <h2>Instructions</h2>
            <div className={styles.recipeInstruction}>

                <ol>
                    {isLoading ? <p>Loading....</p> : food.analyzedInstructions[0].steps.map((step) => (<li>{step.step}</li>))}
                </ol>
            </div>
        </div>

    )
}
